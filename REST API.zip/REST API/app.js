//import files
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const userRouter = require('./Router/userRoute');

//create a app
const app = express();

//dataBase connection with app
require('./Config/dbConnect');


//third party middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));

//Route controlling
app.use('/api', userRouter);


//Home route
app.get('/', (req, res)=>{
    res.sendFile(__dirname + '/View/Home.html');
});


////Error handeling
   //client site
   app.use((req, res, next)=>{
    res.status(404).json({Message: 'Route is not found'});
    next();
   });

   //Server site
   app.use((err, req, res, next)=>{
    console.log(err.message);
    res.status(500).json({Message: 'Server is Broken'});
   });

//exports file
module.exports = app;