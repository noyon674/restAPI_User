//import files
const { default: mongoose } = require('mongoose');
const Mongoose = require('mongoose');

//create a schema or data structure to storing user's dada
const userSchema = Mongoose.Schema({
    id:{
        type: String,
        reuire: true
    },
    name:{
        type: String,
        reuire: true
    },
    age:{
        type: Number,
        reuire: true
    },
    createdOn:{
        type: Date,
        default: Date.now
    }
});

//export schema
module.exports = mongoose.model('User', userSchema);