##### welcome to REST APIs

## we will use MVC architecture

1. /api/user -> GET -->{find all users}

2. /api/user -> GET -->{find one user by id}

3. /api/user -> POST -->{create a user}

4. /api/user -> PETCH -->{update user's information}

5. /api/user -> DELETE -->{delete user informartion}