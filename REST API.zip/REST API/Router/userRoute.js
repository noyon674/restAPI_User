//import files
const Router = require('express').Router();
const {createUser, getAllUsers, getOneUser, updateUser, deleteUser} = require('../Controller/userController');

//All APIs
Router.get('/user', getAllUsers);// get all users 
Router.get('/user/:id', getOneUser);// get one user 
Router.post('/user', createUser);// create a user 
Router.patch('/user/:id', updateUser);// update user info
Router.delete('/user/:id', deleteUser);// delete a user 


//export
module.exports = Router;