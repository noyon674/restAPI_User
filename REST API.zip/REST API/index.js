//import files
const App = require('./app');
const configuration = require('./Config/secrete');

//assign port
const port = configuration.app.port;

//run the server
App.listen(port, ()=>{
    console.log(`server is running at http://localhost:${port}`);
});