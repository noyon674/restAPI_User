//import files
const Mongoose = require('mongoose');
const configuration = require('./secrete');

//dataBase url
 const DBURL = configuration.dbURL.url;

//dataBase connection
Mongoose.connect(DBURL)
.then(()=>{
    console.log(`MongoDB is connected properly.`);
})
.catch((error)=>{
    console.log(error.message);
    process.exit(1);
})