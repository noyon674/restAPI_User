//import files
require('dotenv').config();

const dev = {
    app: {
        port: process.env.PORT || 3000
    },
    dbURL: {
        url: process.env.DB_URL || 'mongodb://localhost:27017/restAPI'
    }
}

//export file
module.exports = dev;