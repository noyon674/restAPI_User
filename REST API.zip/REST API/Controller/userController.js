//import files
const User = require('../Model/userModel');
const {v4: uuidv4} = require('uuid');

//create user api
const createUser = async(req, res)=>{
    try {
        const newUser = new User({
            id: uuidv4(),
            name: req.body.name,
            age: Number(req.body.age)
        });
        await newUser.save();
        res.status(201).json(newUser);
    } catch (error) {
        res.status(500).json(error.message);
    }
};

//get all users api
const getAllUsers = async(req, res)=>{
    try {
        const allUsers = await User.find();
        res.status(200).json(allUsers);
    } catch (error) {
        res.status(500).json(error.message);
    }
};

//get one user by id
const getOneUser = async(req, res)=>{
    try {
        const oneUser = await User.findOne({id: req.params.id});
        res.status(200).json(oneUser);
    } catch (error) {
        res.status(500).json(error.message);
    }
};

//update user's information
const updateUser = async(req, res)=>{
    try {
        const findUser = await User.findOne({id: req.params.id});
        findUser.name = req.body.name;
        findUser.age = Number(req.body.age);

        await findUser.save();
        res.status(200).json('User information is updated.');
    } catch (error) {
        res.status(500).json(error.message);
    }
};

//delete user
const deleteUser = async(req, res)=>{
    try {
        await User.deleteOne({id: req.params.id});
        res.status(200).json("User is deleted.");
    } catch (error) {
        res.status(500).json(error.message);
    }
};
//export
module.exports = {createUser, getAllUsers, getOneUser, updateUser, deleteUser};